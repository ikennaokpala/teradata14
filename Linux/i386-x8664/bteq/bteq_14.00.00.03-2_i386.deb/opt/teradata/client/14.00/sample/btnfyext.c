/***********************************************************************
*  TITLE   : btnfyext.c
*
*  PURPOSE : A sample implementation for Notify Exit
* 
************************************************************************
*
* Copyright by 1995,1996,1998,2002,2003,2007-2011 Teradata Corporation.
* All Rights Reserved.
* TERADATA CONFIDENTIAL AND TRADE SECRET.
*
************************************************************************
*
* NOTES :
* 1) Should include "btnfyext.h"
* 2) The procedure must be called "_dynamn" 
* 3) Output will be written to the following:
*    SAS/C : Dataset defined by the DDNAME NFYOUT if it exists;
*            otherwise output is sent to the terminal.
*    IBM/C : Dataset defined by the DDNAME NFYOUT if it exists;
*            otherwise output will by default go to HFS file
*            named dd:NFYOUT because IBM/C compiled z/OS BTEQ is a
*            POSIX application.
*       WS : The file NFYEXIT.OUT.
*
************************************************************************
* History :
*                       DR
* Revision    Date      DCR   DID Comments
* ----------- --------- ----- --- --------------------------------------
* 14.00.00.01 2011May30 150114 RC185029 For IBM/C compiled load module,
*                                NFYOUT as a ddname is needed.
* 14.00.00.00 2010Mar02 139318 RC185029 Print all parameters for event
*                                NBEventInit.
* 13.10.00.01 2009Aug14 115056 RC185029 SAS/C to IBM/C.
* 13.01.00.00 2009Apr28 115056 AS185119 Single-sourcing file for
*                                workstation and mainframe.
* 13.00.00.01 2008Jan17 90037 AS185119 Updated print specifier for
*                                ActivityCnt from %d to %u.
* 13.00.00.00 2007Dec11 109981 AS185119 Update copyright message to 
*                                indicate Teradata as new owner.
* 08.02.02.00 2003Dec01 68119 SMA Copyright notice comment standardized.
* 08.02.00.00 2002Oct27 58309 SMA Native 64-Bit Support.
*       H5_01 1998Jun29 42562 DMR NOTIFY FEATURE RFC
*       H5_00 1998Jun26 42562 DMR NOTIFY FEATURE RFC
*       H3_01 1996Oct04 37364 SYY Updated for WinCLI 3.1.0
*       H3_00 1995Jan23 34579 CME add Export-like features
*
***********************************************************************/
#include <stdio.h>
#ifdef WIN32
#include <windows.h>
#endif

#ifdef __MVS__
#pragma pack(1)
#endif

/* These typedefs are used in btnfyext.h. */
typedef unsigned int UInt32;
typedef int          Int32;
#include "btnfyext.h"

#if defined(__MVS__)
#define OUTFN "dd:NFYOUT"
#elif defined(__I370__)
#define OUTFN "ddn:NFYOUT*"
#else
#define OUTFN "NFYEXIT.OUT"
#endif

#ifdef WIN32
BOOL DllEntryPoint (
    HANDLE    hDLL,
    DWORD     dwReason,
    LPVOID    lpReserved)
{
    
    switch (dwReason)
        {
        case DLL_PROCESS_ATTACH:
        case DLL_PROCESS_DETACH:
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
        default:
            break;
        }
    return TRUE;
}
#endif

Int32 _dynamn(BTNotifyExitParm *P)
{
    FILE *fp;

    if (!(fp = fopen(OUTFN, "a")))
        return(1);

    switch(P->Event) {
    case NBEventInit :   /* Nothing */
        fprintf(fp, "exit called @ bteq init.\n"); 
        fprintf(fp,
                "              Version Id:       %s.\n",
                P->Vals.Initialize.VersionId);
        fprintf(fp,
                "              Version Id Len:   %u.\n",
                P->Vals.Initialize.VersionLen);
        fprintf(fp,
                "              Utility Id:       %d.\n",
                P->Vals.Initialize.UtilityId);
        fprintf(fp,
                "              Utility Name:     %s.\n",
                P->Vals.Initialize.UtilityName);
        fprintf(fp,
                "              Utility Name Len: %u.\n",
                P->Vals.Initialize.UtilityNameLen);
        fprintf(fp,
                "              User Name:        %s.\n",
                P->Vals.Initialize.UserName);
        fprintf(fp,
                "              User Name Len:    %u.\n",
                P->Vals.Initialize.UserNameLen);
        if (P->Vals.Initialize.UserStringLen)
        {
            fprintf(fp,
                "              User Text:        %s.\n",
                P->Vals.Initialize.UserString);
            fprintf(fp,
                "              User Text Len:    %u.\n",
                P->Vals.Initialize.UserStringLen);
        }
        break;

    case NBEventReqStart :
        fprintf(fp, "exit called @ bteq start request: '%s'.\n",
                P->Vals.ReqStart.Request);
        break;

    case NBEventReqDone :  
        fprintf(fp, "exit called @ bteq request complete.\n");
        break;

    case NBEventFetStart :
        fprintf(fp, 
            "exit called @ bteq fetch: statement %d, request %d activity %u.\n",
            P->Vals.FetStart.StatementNo,
            P->Vals.FetStart.RequestNo,
            P->Vals.FetStart.ActivityCnt);
        break;

    case NBEventComplete :
        fprintf(fp, 
                "exit called @ bteq request processing complete: %d requests\n",
                P->Vals.Complete.RequestCnt);
        break;

    case NBEventDBSRestart :
        fprintf(fp,
                "exit called @ Bteq detects DBS restart.\n");
        break;
 
     case NBEventCLIError :
        fprintf(fp,
                "exit called @ Bteq detects CLI error: %u.\n",
                P->Vals.CLIError.ErrorCode);
        break;
 
     case NBEventDBSError :
        fprintf(fp,
                "exit called @ Bteq detects DBS error: %u.\n",
                P->Vals.DBSError.ErrorCode);
        break;

    case NBEventExit :
        fprintf(fp, "exit called @ bteq notify out of scope: return code %d.\n",
                P->Vals.Exit.ReturnCode);
        break;
    }
    fclose(fp);
        return(0);
}

/**********************************************************************/
/* EndOfCode btnfyext.c */
/************************/
