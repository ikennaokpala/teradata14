/***********************************************************************
* TITLE   : btnfyext.h
************************************************************************
*
* Copyright 1996, 1998, 2002-2003, 2007, 2009-2010
* by Teradata Corporation. All Rights Reserved.
* TERADATA CONFIDENTIAL AND TRADE SECRET.
*
************************************************************************
*
* PURPOSE : The type definitions for BTEQ NOTIFY exit to aid in the
*           implementation of NOTIFY exits.
*
************************************************************************
*
* History :
*                       DR
* Revision    Date      DCR   DID Comments
* ----------- --------- ----- --- --------------------------------------
* 14.00.00.01 2010Mar16 139318 RC185029 Remove coptypes.h and shorteh.h
*                                dependency.
* 13.10.00.01 2009Aug14 115056 RC185029 SAS/C to IBM/C.
* 13.01.00.00 2009Apr28 115056 AS185119 Single-sourcing header file for
*                                       workstation and mainframe.
* 13.00.00.01 2008Jan17 90037  AS185119 Promoted datatype of ActivityCnt
*                                       from Int32 to UInt32.
* 13.00.00.00 2007Dec11 109981 AS185119 Update copyright message to
*                                 indicate Teradata as new owner.
* 12.00.00.00 2007Apr26 112499 AS185119 Updated macro MAXUSERSTRLEN from
*                                       80 to 256.
* 08.02.01.00 2002Dec13 64028 SMA Added TTU7.1 Copyright refs.
* 08.02.00.00 2002Oct26 58309 CSG RC210052/SMA Native 64-Bit OS Support.
*       H5_01 1998Sep24 42562 DMR Renumbered events
*       H5_00 1998Jun26 42562 DMR NOTIFY FEATURE RFC
*       H3_01 1996Jul18 36967 CME SUN compile problems
*       H3_00 1996Feb02 34578 CME 34578 add Export-like features
*
***********************************************************************/
#ifndef BTNFYEXT_H
#define BTNFYEXT_H

#ifdef __MVS__
#pragma pack(1)
#endif

#define BteqBase 41

typedef enum {
    NBEventInit       = 0,
    NBEventReqStart   = 42,
    NBEventReqDone    = 43,
    NBEventFetStart   = 44,
    NBEventComplete   = 45,
    NBEventDBSRestart =  9,
    NBEventCLIError   = 10,
    NBEventDBSError   = 11,
    NBEventExit       = 12
} NfyBTQEvent;

#define MAXVERSIONIDLEN       32
#define MAXUTILITYNAMELEN     32
#define MAXUSERNAMELEN        64
#define MAXUSERSTRLEN        256
#define MAXTABLENAMELEN      128
#define MAXFILENAMELEN       256

typedef struct _BTNotifyExitParm {
    Int32 Event; /* should be NfyBTQEvent values */
    union {
        struct {
         UInt32 VersionLen;
         char   VersionId[MAXVERSIONIDLEN];
         UInt32 UtilityId;
         UInt32 UtilityNameLen;
         char   UtilityName[MAXUTILITYNAMELEN];
         UInt32 UserNameLen;
         char   UserName[MAXUSERNAMELEN];
         UInt32 UserStringLen;
         char   UserString[MAXUSERSTRLEN];
            }Initialize;
        struct {
            char *Request;
            } ReqStart;
        struct {
            int dummy;             /* picky SASC compiler */
            }ReqDone ;
        struct {
            Int32 RequestNo;
            Int32 StatementNo;
            UInt32 ActivityCnt;
            }FetStart ;
        struct {
            Int32 RequestCnt;
            }Complete ;
        struct {
             Int32  dummy;
           } DBSRestart;
        struct {
         UInt32  ErrorCode;
               } CLIError;
        struct {
         UInt32 ErrorCode;
               } DBSError;
        struct {
            Int32 ReturnCode;
            } Exit;
        } Vals;
    } BTNotifyExitParm;

#endif /* BTNFYEXT_H */

/**********************************************************************/
/* EndOfCode btnfyext.h */
/************************/
