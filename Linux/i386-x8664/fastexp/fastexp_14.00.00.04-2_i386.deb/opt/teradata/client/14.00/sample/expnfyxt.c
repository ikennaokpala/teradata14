/***************************************************************************
 *
 * TITLE: expnfyxt.c .... an example notify exit...
 *
 * Copyright1996-2010 by Teradata Corporation.
 * All Rights Reserved.
 * TERADATA CONFIDENTIAL AND TRADE SECRET
 *
 *  Purpose       As a test and an example for users.
 *
 *  Copyright     (C) 2010 Teradata Corporation,
 *                         El Segundo, CA   90245
 *
 *  Description   stuff for notify.
 *
 *  Notes         1) should probably include "expnfyxt.h"
 *                2) the procedure must be called "_dynamn"
 *                3) should return 0 unless there is a problem.
 *
 * History Information
 *
 * Revision    Date     DR    DID     Comments
 * ----------- -------- ----- ------- -----------------------------------
 * 13.01.00.01 04092009 124562 YY151001 FEXP w/o Spooling support
 * 13.01.00.00 09172008 115415 NT185003 SAS/C to IBM/C migration
 * 13.00.00.01 09102007 114415 NT185003 Teradata Corporation Copyright
 * 13.00.00.00 09012007 100895 SV185048 Visual Studio 8.0 build
 * 07.08.00.01 09292005 96207 CSG     Port to HP-UX IA64
 * 07.06.00.00 08012001 56478 CSG     Add #ifdef WIN32 for NT
 * 07.05.00.00 03122001 53284 CSG     Port FEXP to HP-UX
 * 07.02.00.01 09301998 44116 SFD     Source line too long for VM
 * 07.02.00.00 06221998 42570 SFD     Update NOTIFY EXIT interface
 *
 *  History       H3_00  95Oct29  CME  DR 34580 add Export-like features
 *
 ***************************************************************************/
/* DR115415 ==> */
#ifdef __MVS__
#pragma pack(1)
#endif
/* DR115415 <== */
#include <stdio.h>
typedef unsigned int UInt32;                           /*DR53284 */
typedef int Int32;               /* DR 96207 */
#include "expnfyxt.h"

#ifdef WIN32                           /* Change for WIN32 DR56478*/
__declspec(dllexport) Int32 _dynamn(FXNotifyExitParm *P) /*DR96207*/
#else                                                    /*DR56478*/
Int32 _dynamn( FXNotifyExitParm *P)                     /*DR96207*/
#endif                                                   /*DR56478*/
{
    FILE *fp;

    if (!(fp = fopen("NFYEXIT.OUT", "a")))
        return(1);

    switch(P->Event) {
    case NXEventInitialize :   /* Nothing */
        fprintf(fp, "exit called @ fexp init.\n");
        fprintf(fp, "Version: %s\n", P->Vals.Initialize.VersionId);
        fprintf(fp, "Utility: %s\n", P->Vals.Initialize.UtilityName);
        fprintf(fp, "User: %s\n", P->Vals.Initialize.UserName);
        if (P->Vals.Initialize.UserStringLen)
           fprintf(fp, "UserString: %s\n", P->Vals.Initialize.UserString);
        break;

    case NXEventFileInmodOpen:
        fprintf(fp, "exit called @ input file open: %s\n",
                P->Vals.FileInmodOpen.FileOrInmodName);
        break;

    case NXEventDBSRestart :
        fprintf(fp, "exit called @ RDBMS restart detected\n");
        break;

    case NXEventCLIError :
        fprintf(fp, "exit called @ CLI error %d\n",
                P->Vals.CLIError.ErrorCode);
        break;

    case NXEventDBSError :
        fprintf(fp, "exit called @ DBS error %d\n",
                P->Vals.DBSError.ErrorCode);
        break;

    case NXEventExit :
        fprintf(fp,
           "exit called @ fexp notify out of scope: return code %d.\n",
            P->Vals.Exit.ReturnCode);
        break;

    case NXEventExportBegin :
        fprintf(fp, "exit called @ export beginning.\n");
        break;

    case NXEventReqSubmitBegin :
        fprintf(fp, "exit called @ request submitted: '%s'.\n",
            P->Vals.ReqSubmitBegin.Request);
        break;

    case NXEventReqSubmitEnd :
        fprintf(fp, "exit called @ request done: %d statement(s), \
%d blocks.\n",
            P->Vals.ReqSubmitEnd.StatementCnt,
            P->Vals.ReqSubmitEnd.BlockCnt);
        break;

    case NXEventReqFetchBegin :
        fprintf(fp, "exit called @ request fetch beginning.\n");
        break;

    case NXEventFileOutmodOpen:
        fprintf(fp, "exit called @ output file open: %s\n",
                P->Vals.FileOutmodOpen.FileOrOutmodName);
        break;

    case NXEventStmtFetchBegin :
        fprintf(fp, "exit called @ statement fetch beginning: stmt #%d, \
%d blocks.\n",
            P->Vals.StmtFetchBegin.StatementNo,
            P->Vals.StmtFetchBegin.BlockCnt);
        break;

    case NXEventStmtFetchEnd :
        fprintf(fp, "exit called @ statement fetch end: %d records.\n",
            P->Vals.StmtFetchEnd.Records);
        break;

    case NXEventReqFetchEnd :
        fprintf(fp, "exit called @ request fetch ends: \
Records exported: %d, Records rejected: %d\n",
            P->Vals.ReqFetchEnd.RecsExported,
            P->Vals.ReqFetchEnd.RecsRejected);
        break;

    case NXEventExportEnd :
        fprintf(fp, "exit called @ export ends: \
Records exported: %d, Records rejected: %d\n",
            P->Vals.ExportEnd.RecsExported,
            P->Vals.ExportEnd.RecsRejected);
        break;

    case NXEventBlockCount :                                 /*DR124562*/
        fprintf(fp, "exit called @ request done in Nospool mode: %d \
blocks.\n", P->Vals.BlockCount.BlockCount);
        break;
    }
    fclose(fp);
    return(0);
}
