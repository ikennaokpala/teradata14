#ifndef DBCA2PX_H
#define DBCA2PX_H
#define DBCA2PX_H_REV "13.10.00.00"
/*******************************************************************************
 *  TITLE:       DBCA2PX.H .. CLIv2 DBC Extension Area for 2PC       13.10.00.00
 *                                                             
 *  Purpose      To contain the DBC Extension Area for 2PC.
 *                                                             
 *  Copyright 1994-2009 by Teradata Corporation.  All rights reserved.
 *  TERADATA CONFIDENTIAL AND TRADE SECRET.
 *                                                             
 *  Description  This include file contains the 2PC Extension            
 *               Area needed for an application program 
 *               to make calls for 2PC CLIv2.                       
 *                                                             
 *  History                                                    
 *    H0_00  94Apr04  JAE  DCR6172  Created for Release 5.0 2PC/CLI.   
 *    H3_00  95Sep13  TH4  DR34047  Added the #ifndef XXXX #define XXXX. 
 *    04.00.00.01 TH4 96Jul12 DR36785 Version number change.
 *    04.08.00.00 07/23/2003 mg180007 DR68139 self-sufficient headers
 *    04.08.01.00 04/21/2005 mg180007 DR93472 added header revision info
 *    13.00.00.00 2008Jan09  mg180007 DR117140 copyright update
 *    13.10.00.00 2009Jun23  kl185018 DR133468 TTU13.1 Version Renumbering 
 *                                             to TTU13.10
 ******************************************************************************/

#include <coptypes.h> /* DR68139 */

/***************************************************************/
/*  DBF2PC Subfunction Codes                                   */
/***************************************************************/

#define         DBX2FVR         1
#define         DBX2FVT         2
#define         DBX2FEW         3
#define         DBX2FAW         4
#define         DBX2FOSI        5
#define         DBX2FSC         6

/***************************************************************/
/*  BIT MASKING FLAGS FOR dbx2o_attr_flag                      */
/***************************************************************/
#define        DBX2OEAA        1
#define        DBX2OEAC        2
#define        DBX2OEAR        8
 
/***************************************************************/
/*  BIT MASKING FLAGS FOR dbx2oe_state                         */
/***************************************************************/
#define        DBX2OESR        1
#define        DBX2OESS        3
#define        DBX2OESV        7
#define        DBX2OESD        15
#define        DBX2OEST        31
#define        DBX2OESC        63


/*****************************************************************/
/*              2PC TYPE DEFINITIONS/STRUCTURES                  */
/*****************************************************************/

/*****************************************************************/
/*             SessInfoOutputEntry                               */
/*                                                               */
/*  This structure is part of the SessInfoOutput Array that is   */
/*  returned to the application when requested.                  */
/*  An entry exists for each 2PC session.                        */
/*                                                               */
/*****************************************************************/

typedef struct
{
  Int16        dbx2oe_entry_len;   /* entry total length         */
  char         dbx2oe_level;       /* level - mainframe only     */
  char         dbx2oe_filler_1;    /* reserved                   */
  Int32        dbx2oe_dbc_sess_id; /* dbc session identifier     */
  Int32        dbx2oe_sess_id;     /* connection identifier      */
  Int32        dbx2oe_req_id;      /* active request identifier  */
  char         dbx2oe_tdp_id[8];   /* tdp-id - mainframe only    */
  unsigned char dbx2oe_attr_flag;  /* transaction attribute flag */
  unsigned char dbx2oe_state;      /* transaction state flag     */
  char          dbx2oe_filler_2[2]; /* reserved                  */
  char          dbx2oe_filler_3[8]; /* reserved                  */
} SessInfoOutputEntry;
 
/*****************************************************************/
/*            SessInfoOutputArray                                */
/*                                                               */
/*  This structure contains the 2PC session information that is  */
/*  returned to the application when requested.                  */
/*****************************************************************/
 
struct SessInfoOutputArray
{
  Int16        dbx2o_num_sess_q;  /* number of sessions involved */
  Int16        dbx2o_num_sess_r;  /* number of sessions returned */
  char         dbx2o_level;       /* level - mainframe only      */
  char         dbx2o_sum_flag;    /* summary flag - mainframe    */
  char         dbx2o_filler_1[2]; /* reserved                    */
  SessInfoOutputEntry dbx2o_entry[1];
};

/***************************************************************/
/*              DBC EXTENSION AREA FOR 2PC                     */ 
/*                                                             */
/*  This extension area is for 2PC functions.                  */
/*  For 2PC, the dbcarea extension pointer will point to this  */
/*  extension area.                                            */
/***************************************************************/

struct DBCA2PX
{
  char         dbx2_id[4];        /* area identifier ("DBX2")  */ 
  Int16        dbx2_len;          /* length of extension area  */
  Byte         dbx2_func;         /* subfunction code          */
  char         filler_1;          /* reserved                  */
  char         dbx2_tdp[8];       /* tdp identifier (mainframe)*/
  Int16        dbx2_ruid_len;     /* length of run-unit id     */
  Int16        dbx2_coid_len;     /* length of coordinator id  */
  char        *dbx2_ruid_ptr;     /* pointer to run-unit id    */
  char        *dbx2_coid_ptr;     /* pointer to coordinator id */
  Int32        dbx2_odata_len;    /* length of output data     */
  char        *dbx2_odata_ptr;    /* pointer to output data    */
};

/***************************************************************/
/*                       END of DBCA2PX.h                      */
/***************************************************************/
#endif /* DBCA2PX_H */
